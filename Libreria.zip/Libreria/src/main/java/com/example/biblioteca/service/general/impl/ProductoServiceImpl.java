package com.example.biblioteca.service.general.impl;

import com.example.biblioteca.dto.ProductoDTO;
import com.example.biblioteca.entity.Producto;
import com.example.biblioteca.mapper.ProductoMapper;
import com.example.biblioteca.repository.ProductoRepository;
import com.example.biblioteca.service.general.service.ProductoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductoServiceImpl implements ProductoService {
    private final ProductoRepository repository;
    private final ProductoMapper mapper;

    @Override
    public List<ProductoDTO> findAll() {
        return repository.findAll().stream().map(mapper::toDto).toList();
    }

    @Override
    public Optional<ProductoDTO> findById(Long id) {
        return repository.findById(id).map(mapper::toDto);
    }

    @Override
    public ProductoDTO save(ProductoDTO dto) {
        Producto entity = mapper.toEntity(dto);
        return mapper.toDto(repository.save(entity));
    }

    @Override
    public ProductoDTO update(ProductoDTO dto) {
        Producto entity = mapper.toEntity(dto);
        return mapper.toDto(repository.save(entity));
    }

    @Override
    public void deleteLogic(Long id) {
        Producto entity = repository.findById(id).orElseThrow();
        entity.setIdestado(0); // lógico
        repository.save(entity);
    }
}
