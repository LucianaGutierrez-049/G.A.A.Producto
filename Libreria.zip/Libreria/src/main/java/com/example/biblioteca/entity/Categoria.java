package com.example.biblioteca.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@EqualsAndHashCode(callSuper = false)
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Table(name = "CATEGORIA")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // funciona si usaste "GENERATED AS IDENTITY"
    @Column(name = "IDCATEGORIA", nullable = false, updatable = false)
    private Long idcategoria;

    @NotNull(message = "La descripción no puede estar en blanco")
    @Column(name = "DESCRIPCION", nullable = false, length = 255)
    private String descripcion;
}
