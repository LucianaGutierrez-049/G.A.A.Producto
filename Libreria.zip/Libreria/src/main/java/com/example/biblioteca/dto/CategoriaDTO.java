package com.example.biblioteca.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;

@Data
public class CategoriaDTO {
    private Long id;

    @NotBlank(message = "La descripción de la categoría no puede estar vacía")
    private String descripcion;
}
