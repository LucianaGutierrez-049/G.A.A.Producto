package com.example.biblioteca.service.general.service;

import com.example.biblioteca.dto.ProductoDTO;

import java.util.List;
import java.util.Optional;

public interface ProductoService {
    List<ProductoDTO> findAll();
    Optional<ProductoDTO> findById(Long id);
    ProductoDTO save(ProductoDTO dto);
    ProductoDTO update(ProductoDTO dto);
    void deleteLogic(Long id); // lógico con idestado=0
}
