package com.example.biblioteca.mapper;

import com.example.biblioteca.dto.ProductoDTO;
import com.example.biblioteca.entity.Producto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ProductoMapper {
    @Mapping(source = "idproducto", target = "id")
    @Mapping(source = "categoria.idcategoria", target = "idcategoria")
    ProductoDTO toDto(Producto entity);

    @Mapping(source = "id", target = "idproducto")
    @Mapping(source = "idcategoria", target = "categoria.idcategoria")
    Producto toEntity(ProductoDTO dto);
}
