package com.example.biblioteca.service.general.service;

import com.example.biblioteca.dto.CategoriaDTO;

import java.util.List;
import java.util.Optional;

public interface CategoriaService {
    List<CategoriaDTO> findAll();
    Optional<CategoriaDTO> findById(Long id);
    CategoriaDTO save(CategoriaDTO dto);
    CategoriaDTO update(CategoriaDTO dto);
    void delete(Long id); // físico

}
