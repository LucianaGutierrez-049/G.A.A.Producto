package com.example.biblioteca.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = false)
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Table(name = "PRODUCTO")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IDPRODUCTO", nullable = false, updatable = false)
    private Long idproducto;

    @NotNull(message = "El nombre no puede estar en blanco")
    @Column(name = "NOMBRE", nullable = false, length = 255)
    private String nombre;

    @NotNull(message = "El precio no puede estar vacío")
    @Column(name = "PRECIO", nullable = false, precision = 10, scale = 2)
    private BigDecimal precio;


    @NotNull(message = "El stock no puede estar vacío")
    @Column(name = "STOCK", nullable = false)
    private Integer stock;

    @ManyToOne
    @JoinColumn(name = "IDCATEGORIA", referencedColumnName = "IDCATEGORIA")
    private Categoria categoria;

    @NotNull(message = "El estado no puede estar vacío")
    @Column(name = "IDESTADO", nullable = false)
    private Integer idestado;
}
