package com.example.biblioteca.mapper;

import com.example.biblioteca.dto.CategoriaDTO;
import com.example.biblioteca.entity.Categoria;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CategoriaMapper {
    @Mapping(source = "idcategoria", target = "id")
    CategoriaDTO toDto(Categoria entity);

    @Mapping(source = "id", target = "idcategoria")
    Categoria toEntity(CategoriaDTO dto);
}
