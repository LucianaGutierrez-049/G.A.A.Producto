package com.example.biblioteca.service.general.impl;

import com.example.biblioteca.dto.CategoriaDTO;
import com.example.biblioteca.entity.Categoria;
import com.example.biblioteca.mapper.CategoriaMapper;
import com.example.biblioteca.repository.CategoriaRepository;
import com.example.biblioteca.service.general.service.CategoriaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CategoriaServiceImpl implements CategoriaService {
    private final CategoriaRepository repository;
    private final CategoriaMapper mapper;

    @Override
    public List<CategoriaDTO> findAll() {
        return repository.findAll().stream().map(mapper::toDto).toList();
    }

    @Override
    public Optional<CategoriaDTO> findById(Long id) {
        return repository.findById(id).map(mapper::toDto);
    }

    @Override
    public CategoriaDTO save(CategoriaDTO dto) {
        Categoria entity = mapper.toEntity(dto);
        return mapper.toDto(repository.save(entity));
    }

    @Override
    public CategoriaDTO update(CategoriaDTO dto) {
        Categoria entity = mapper.toEntity(dto);
        return mapper.toDto(repository.save(entity));
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
}
